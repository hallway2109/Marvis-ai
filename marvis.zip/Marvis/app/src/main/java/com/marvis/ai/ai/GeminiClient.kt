package com.marvis.ai.ai

import com.marvis.ai.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

typealias ToolExecutor = suspend (name: String, args: JSONObject) -> JSONObject

data class MarvisReply(val text: String, val emotion: Emotion)

/**
 * Multimodal Gemini client (text + screenshot + function calling) over the REST API.
 * The model's raw content is stored in history untouched, which preserves Gemini 3
 * "thought signatures" that must be echoed back during function-calling turns.
 */
class GeminiClient(
    private val apiKey: String = BuildConfig.GEMINI_API_KEY,
    private val model: String = BuildConfig.GEMINI_MODEL,
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json".toMediaType()
    private val history = JSONArray()
    private val tools = MarvisTools.functionDeclarations

    suspend fun chat(
        userText: String,
        screenJpegBase64: String?,
        nowDescription: String,
        execute: ToolExecutor,
    ): MarvisReply = withContext(Dispatchers.IO) {
        require(apiKey.isNotBlank()) { "GEMINI_API_KEY is missing. Add it to local.properties." }

        if (screenJpegBase64 != null) stripOldImages()
        val parts = JSONArray().put(JSONObject().put("text", userText))
        if (screenJpegBase64 != null) {
            parts.put(JSONObject().put("inlineData",
                JSONObject().put("mimeType", "image/jpeg").put("data", screenJpegBase64)))
        }
        history.put(JSONObject().put("role", "user").put("parts", parts))
        trimHistory()

        var rounds = 0
        while (true) {
            val resp = post(buildBody(nowDescription))
            val content = resp.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                ?: return@withContext MarvisReply(
                    "[[calm]] I couldn't produce an answer. ${resp.optJSONObject("promptFeedback") ?: ""}".trim(),
                    Emotion.CALM)
            content.put("role", "model")
            history.put(content)

            val modelParts = content.optJSONArray("parts") ?: JSONArray()
            val calls = (0 until modelParts.length()).map { modelParts.getJSONObject(it) }
                .filter { it.has("functionCall") }

            if (calls.isEmpty()) return@withContext parseReply(modelParts)

            val responses = JSONArray()
            for (p in calls) {
                val fc = p.getJSONObject("functionCall")
                val name = fc.getString("name")
                val result = try { execute(name, fc.optJSONObject("args") ?: JSONObject()) }
                catch (e: Exception) { JSONObject().put("ok", false).put("error", e.message ?: "failed") }
                val fr = JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                if (fc.optString("id").isNotEmpty()) fr.put("id", fc.getString("id"))
                responses.put(JSONObject().put("functionResponse", fr))
            }
            history.put(JSONObject().put("role", "user").put("parts", responses))
            if (++rounds >= 6) return@withContext MarvisReply("[[calm]] Done.", Emotion.CALM)
        }
        error("unreachable")
    }

    private fun buildBody(now: String) = JSONObject()
        .put("systemInstruction", JSONObject().put("parts",
            JSONArray().put(JSONObject().put("text", SystemPrompt.build(now)))))
        .put("contents", history)
        .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", tools)))

    private fun post(body: JSONObject): JSONObject {
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .header("x-goog-api-key", apiKey)
            .post(body.toString().toRequestBody(jsonType))
            .build()
        http.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("Gemini ${r.code}: ${text.take(300)}")
            return JSONObject(text)
        }
    }

    private fun parseReply(parts: JSONArray): MarvisReply {
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought")) sb.append(p.getString("text"))
        }
        val raw = sb.toString().trim()
        val m = Regex("^\\s*\\[\\[(\\w+)]]\\s*").find(raw)
        return MarvisReply(raw.removePrefix(m?.value ?: "").trim(), Emotion.fromTag(m?.groupValues?.get(1)))
    }

    /** Keep only the newest screenshot in context to save tokens. */
    private fun stripOldImages() {
        for (i in 0 until history.length()) {
            val parts = history.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in parts.length() - 1 downTo 0) {
                if (parts.getJSONObject(j).has("inlineData")) {
                    parts.put(j, JSONObject().put("text", "[earlier screenshot omitted]"))
                }
            }
        }
    }

    /** Drop oldest turns, but only cut at a plain user text turn so call/response pairs stay intact. */
    private fun trimHistory(max: Int = 40) {
        while (history.length() > max) {
            history.remove(0)
            while (history.length() > 0 && !isPlainUserTurn(history.getJSONObject(0))) history.remove(0)
        }
    }

    private fun isPlainUserTurn(c: JSONObject): Boolean {
        if (c.optString("role") != "user") return false
        val ps = c.optJSONArray("parts") ?: return false
        return (0 until ps.length()).none { ps.getJSONObject(it).has("functionResponse") }
    }
}
