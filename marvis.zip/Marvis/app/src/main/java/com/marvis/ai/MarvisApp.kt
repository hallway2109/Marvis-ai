package com.marvis.ai

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.room.Room
import com.marvis.ai.reminders.MarvisDatabase
import com.marvis.ai.reminders.TaskReminderManager

class MarvisApp : Application() {
    companion object {
        const val CHANNEL_REMINDERS = "reminders"
        lateinit var instance: MarvisApp
    }

    lateinit var db: MarvisDatabase
    val reminders by lazy { TaskReminderManager(this, db.reminderDao()) }

    override fun onCreate() {
        super.onCreate()
        instance = this
        db = Room.databaseBuilder(this, MarvisDatabase::class.java, "marvis.db").build()
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_REMINDERS, "Reminders & alarms", NotificationManager.IMPORTANCE_HIGH))
    }
}
