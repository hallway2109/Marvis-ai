package com.marvis.ai.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.marvis.ai.ai.Emotion
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MarvisMainScreen(vm: MarvisViewModel, onOpenAccessibility: () -> Unit) {
    val s by vm.state.collectAsStateWithLifecycle()
    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(MarvisBgTop, MarvisBgBottom)))
            .systemBarsPadding().imePadding()
    ) {
        TopBar(s, onOpenAccessibility)

        // "Click the screen": tapping the orb toggles listening / interrupts speech.
        Box(
            Modifier.fillMaxWidth().height(230.dp).clickable(
                interactionSource = remember { MutableInteractionSource() }, indication = null
            ) { vm.onMicClick() },
            contentAlignment = Alignment.Center
        ) { MarvisOrb(s.orb, s.emotion, s.level, Modifier.fillMaxSize()) }

        if (s.partial.isNotBlank()) {
            Text(s.partial, Modifier.padding(horizontal = 24.dp).fillMaxWidth(),
                color = Color(0xFFB8C0D8), fontSize = 15.sp)
        }

        val list = rememberLazyListState()
        LaunchedEffect(s.messages.size) { if (s.messages.isNotEmpty()) list.animateScrollToItem(s.messages.lastIndex) }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), state = list,
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(s.messages, key = { it.id }) { Bubble(it) }
        }

        InputBar(
            text = s.input, listening = s.listening, screenShare = s.screenShare,
            onText = vm::onInputChange, onSend = vm::sendTyped,
            onMic = vm::onMicClick, onShare = vm::toggleScreenShare)
    }
}

@Composable
private fun TopBar(s: UiState, onA11y: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("MARVIS", fontSize = 18.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp)
            Text(when (s.orb) {
                OrbState.IDLE -> "Online"; OrbState.LISTENING -> "Listening…"
                OrbState.THINKING -> "Thinking…"; OrbState.SPEAKING -> "Speaking"
            }, fontSize = 12.sp, color = Color(0xFF8A93AD))
        }
        IconButton(onClick = onA11y) {
            Icon(Icons.Rounded.Accessibility, "Accessibility",
                tint = if (s.a11yEnabled) Color(0xFF5CE1A0) else Color(0xFFFFB74D))
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (m.fromUser) Arrangement.End else Arrangement.Start) {
        Text(m.text,
            Modifier.widthIn(max = 300.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(if (m.fromUser) Color(0xFF2A3350) else Color(0x331E2640))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            fontSize = 15.sp, color = Color(0xFFE6E9F2))
    }
}

/** Gemini-style pill: text field + screen-share toggle + (mic | send). */
@Composable
private fun InputBar(
    text: String, listening: Boolean, screenShare: Boolean,
    onText: (String) -> Unit, onSend: () -> Unit, onMic: () -> Unit, onShare: () -> Unit,
) {
    Surface(
        Modifier.fillMaxWidth().padding(12.dp),
        shape = RoundedCornerShape(32.dp), color = MarvisSurface, tonalElevation = 2.dp
    ) {
        Row(Modifier.padding(start = 20.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(
                value = text, onValueChange = onText,
                modifier = Modifier.weight(1f).heightIn(min = 40.dp),
                textStyle = TextStyle(color = Color(0xFFE6E9F2), fontSize = 16.sp),
                cursorBrush = SolidColor(Color(0xFF7C9CFF)),
                maxLines = 5,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() }),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (text.isEmpty()) Text("Ask Marvis", color = Color(0xFF7A839E), fontSize = 16.sp)
                        inner()
                    }
                })
            IconButton(onClick = onShare) {
                Icon(if (screenShare) Icons.Rounded.ScreenShare else Icons.Rounded.StopScreenShare,
                    "Screen share", tint = if (screenShare) Color(0xFF5CE1A0) else Color(0xFF8A93AD))
            }
            AnimatedContent(targetState = text.isNotBlank(), label = "mic-send") { hasText ->
                if (hasText) {
                    IconButton(onClick = onSend, modifier = Modifier.clip(CircleShape).background(Color(0xFF7C9CFF))) {
                        Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Color(0xFF0B1020))
                    }
                } else {
                    IconButton(onClick = onMic,
                        modifier = Modifier.clip(CircleShape).background(if (listening) Color(0xFFFF5C7A) else Color(0xFF2A3350))) {
                        Icon(if (listening) Icons.Rounded.Stop else Icons.Rounded.Mic, "Microphone", tint = Color.White)
                    }
                }
            }
        }
    }
}

/** Glowing orb: colour = emotion, energy = state/mic level, rippling wave ring. */
@Composable
fun MarvisOrb(state: OrbState, emotion: Emotion, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "phase")
    val breathe by t.animateFloat(0.96f, 1.04f,
        infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe")
    val amp by animateFloatAsState(level, tween(120), label = "amp")
    val color by animateColorAsState(Color(emotion.argb), tween(600), label = "color")

    val energy = when (state) {
        OrbState.IDLE -> 0.12f
        OrbState.LISTENING -> 0.25f + amp * 0.75f
        OrbState.THINKING -> 0.45f
        OrbState.SPEAKING -> 0.40f + 0.30f * (sin(phase * 5f) * 0.5f + 0.5f)
    }
    val spin = if (state == OrbState.THINKING) phase * 3f else phase

    Canvas(modifier) {
        val c = center
        val r = size.minDimension / 4.2f * breathe * (1f + energy * 0.12f)

        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent), c, r * 2.6f), r * 2.6f, c)
        for (i in 0..2) {
            val rr = r * (1.35f + i * 0.28f) + r * 0.12f * energy * sin(phase * (i + 1) + i)
            drawCircle(color.copy(alpha = 0.22f - i * 0.06f), rr, c, style = Stroke(1.5f.dp.toPx()))
        }
        val path = Path()
        val steps = 160
        for (i in 0..steps) {
            val a = i / steps.toFloat() * 2f * PI.toFloat()
            val rad = r * 1.18f + r * 0.16f * energy * sin(6f * a + spin) + r * 0.06f * energy * sin(11f * a - spin * 1.6f)
            val p = Offset(c.x + rad * cos(a), c.y + rad * sin(a))
            if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y)
        }
        path.close()
        drawPath(path, color.copy(alpha = 0.85f), style = Stroke(2.5f.dp.toPx()))
        drawCircle(Brush.radialGradient(
            listOf(Color.White.copy(alpha = 0.95f), color, color.copy(alpha = 0.25f)),
            c - Offset(r * 0.25f, r * 0.3f), r * 1.1f), r, c)
    }
}
