package com.marvis.ai.ai

/** Emotional tone: drives TTS prosody AND the orb colour. */
enum class Emotion(val tag: String, val pitch: Float, val rate: Float, val argb: Long) {
    WARM("warm", 0.95f, 0.92f, 0xFFFFA45C),
    FRIENDLY("friendly", 1.05f, 1.00f, 0xFF4FC3F7),
    CALM("calm", 0.90f, 0.85f, 0xFF7C9CFF),
    ENTHUSIASTIC("enthusiastic", 1.20f, 1.12f, 0xFFFF6BD6);

    companion object {
        fun fromTag(t: String?) = entries.firstOrNull { it.tag.equals(t, true) } ?: FRIENDLY
    }
}
