package com.marvis.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.marvis.ai.device.AppForeground
import com.marvis.ai.device.ScreenCaptureService
import com.marvis.ai.ui.MarvisMainScreen
import com.marvis.ai.ui.MarvisTheme
import com.marvis.ai.ui.MarvisViewModel
import com.marvis.ai.ui.UiEvent
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: MarvisViewModel by viewModels()

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.onMicPermissionResult(it)
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val projection = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data ?: return@registerForActivityResult
        ContextCompat.startForegroundService(this,
            Intent(this, ScreenCaptureService::class.java).putExtra("code", r.resultCode).putExtra("data", data))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (Build.VERSION.SDK_INT >= 33) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        lifecycleScope.launch {
            vm.events.collect {
                when (it) {
                    UiEvent.RequestMic -> micPermission.launch(Manifest.permission.RECORD_AUDIO)
                    UiEvent.RequestProjection -> projection.launch(
                        (getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).createScreenCaptureIntent())
                }
            }
        }
        setContent {
            MarvisTheme {
                MarvisMainScreen(vm) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        AppForeground.visible = true
        AppForeground.minimize = { moveTaskToBack(true) }
    }

    override fun onStop() { AppForeground.visible = false; super.onStop() }

    override fun onResume() { super.onResume(); vm.refreshA11y() }
}
