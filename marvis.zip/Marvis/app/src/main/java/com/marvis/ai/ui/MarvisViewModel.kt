package com.marvis.ai.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.marvis.ai.ai.Emotion
import com.marvis.ai.ai.GeminiClient
import com.marvis.ai.device.ActionRouter
import com.marvis.ai.device.MarvisAccessibilityService
import com.marvis.ai.device.ScreenCaptureHelper
import com.marvis.ai.voice.SpeechManager
import com.marvis.ai.voice.TtsManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

data class ChatMessage(val id: Long, val fromUser: Boolean, val text: String)

data class UiState(
    val messages: List<ChatMessage> = emptyList(),
    val input: String = "",
    val listening: Boolean = false,
    val thinking: Boolean = false,
    val speaking: Boolean = false,
    val level: Float = 0f,
    val partial: String = "",
    val emotion: Emotion = Emotion.CALM,
    val screenShare: Boolean = false,
    val a11yEnabled: Boolean = false,
) {
    val orb: OrbState get() = when {
        thinking -> OrbState.THINKING
        speaking -> OrbState.SPEAKING
        listening -> OrbState.LISTENING
        else -> OrbState.IDLE
    }
}

sealed interface UiEvent {
    data object RequestMic : UiEvent
    data object RequestProjection : UiEvent
}

class MarvisViewModel(private val app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(UiState())
    val state = _state.asStateFlow()
    private val _events = MutableSharedFlow<UiEvent>(extraBufferCapacity = 4)
    val events = _events.asSharedFlow()

    private val gemini = GeminiClient()
    private val router = ActionRouter(app)
    private var nextId = 0L

    private val tts = TtsManager(app) { s -> _state.update { it.copy(speaking = s) } }
    private val speech = SpeechManager(app, object : SpeechManager.Callback {
        override fun onPartial(text: String) = _state.update { it.copy(partial = text) }
        override fun onLevel(level: Float) = _state.update { it.copy(level = level) }
        override fun onFinal(text: String) {
            _state.update { it.copy(listening = false, partial = "", level = 0f) }
            submit(text)
        }
        override fun onEnd() = _state.update { it.copy(listening = false, partial = "", level = 0f) }
        override fun onError(message: String) {
            _state.update { it.copy(listening = false, partial = "", level = 0f) }
            addMessage(false, message)
        }
    })

    fun refreshA11y() = _state.update { it.copy(a11yEnabled = MarvisAccessibilityService.isRunning) }

    fun onInputChange(s: String) = _state.update { it.copy(input = s) }

    fun sendTyped() {
        val t = _state.value.input.trim()
        if (t.isEmpty()) return
        _state.update { it.copy(input = "") }
        submit(t)
    }

    /** Mic button and "click the orb" both land here. */
    fun onMicClick() {
        val s = _state.value
        when {
            s.listening -> speech.stop()
            s.speaking -> tts.stop()
            !hasMic() -> _events.tryEmit(UiEvent.RequestMic)
            else -> startListening()
        }
    }

    fun onMicPermissionResult(granted: Boolean) { if (granted) startListening() }

    private fun startListening() {
        tts.stop()
        _state.update { it.copy(listening = true, partial = "") }
        speech.start()
    }

    fun toggleScreenShare() {
        val on = !_state.value.screenShare
        _state.update { it.copy(screenShare = on) }
        if (on && !MarvisAccessibilityService.isRunning && !ScreenCaptureHelper.hasProjection) {
            _events.tryEmit(UiEvent.RequestProjection)
        }
    }

    private fun hasMic() = ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun addMessage(fromUser: Boolean, text: String) =
        _state.update { it.copy(messages = it.messages + ChatMessage(nextId++, fromUser, text)) }

    private fun submit(text: String) {
        addMessage(true, text)
        _state.update { it.copy(thinking = true) }
        viewModelScope.launch {
            try {
                var shot: String? = null
                if (_state.value.screenShare) {
                    com.marvis.ai.device.AppForeground.ensureBackground() // so Gemini sees the OTHER app
                    shot = ScreenCaptureHelper.captureJpegBase64()
                }
                val now = ZonedDateTime.now().format(DateTimeFormatter.ofPattern("EEEE, yyyy-MM-dd HH:mm (zzzz)"))
                val reply = gemini.chat(text, shot, now, router::execute)
                _state.update { it.copy(emotion = reply.emotion) }
                addMessage(false, reply.text)
                tts.speak(reply.text, reply.emotion)
            } catch (e: Exception) {
                addMessage(false, "Something went wrong: ${e.message}")
            } finally {
                _state.update { it.copy(thinking = false) }
            }
        }
    }

    override fun onCleared() { speech.release(); tts.release() }
}
