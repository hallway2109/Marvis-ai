package com.marvis.ai.device

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.Surface
import com.marvis.ai.MarvisApp
import com.marvis.ai.reminders.Repeat
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/** Maps Gemini function calls to real device actions. */
class ActionRouter(private val ctx: Context) {

    private fun good(msg: String = "done") = JSONObject().put("ok", true).put("message", msg)
    private fun fail(msg: String) = JSONObject().put("ok", false).put("error", msg)
    private fun Outcome.json() = if (ok) good(message) else fail(message)
    private fun Boolean.json(yes: String, no: String) = if (this) good(yes) else fail(no)

    private val noA11y = "Accessibility service isn't enabled. Ask the user to enable Marvis in Accessibility settings."

    private fun desired(args: JSONObject): Boolean? = when (args.optString("state")) {
        "on" -> true; "off" -> false; else -> null
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (MarvisAccessibilityService.instance ?: ctx).startActivity(i)
    }

    suspend fun execute(name: String, args: JSONObject): JSONObject {
        // Non-device tools first (no need to leave the Marvis UI)
        when (name) {
            "set_reminder" -> return setReminder(args)
            "list_reminders" -> return listReminders()
            "cancel_reminder" -> {
                MarvisApp.instance.reminders.cancel(args.getLong("id")); return good("Reminder cancelled")
            }
        }

        AppForeground.ensureBackground()
        val a11y = MarvisAccessibilityService.instance
        val needsA11y = setOf("scroll", "tap", "click_text", "type_text", "system_action", "toggle_wifi",
            "toggle_bluetooth", "toggle_mobile_data", "read_screen_text")
        if (name in needsA11y && a11y == null) return fail(noA11y)

        return when (name) {
            "scroll" -> a11y!!.scroll(args.optString("direction") != "up").json("Scrolled", "Couldn't scroll here")
            "tap" -> a11y!!.tap(args.getDouble("x").toFloat(), args.getDouble("y").toFloat()).json("Tapped", "Tap failed")
            "click_text" -> a11y!!.clickByLabel(listOf(args.getString("text"))).json("Clicked", "No matching element on screen")
            "type_text" -> a11y!!.typeText(args.getString("text")).json("Typed", "No text field is focused")
            "system_action" -> a11y!!.global(args.getString("action")).json("Done", "Action failed")
            "read_screen_text" -> good(a11y!!.dumpScreenText())
            "open_app" -> openApp(args.getString("app_name"))
            "toggle_wifi" -> a11y!!.toggleSwitch(Intent(Settings.Panel.ACTION_WIFI), listOf("Wi-Fi", "Wi‑Fi", "Use Wi-Fi"), desired(args)).json()
            "toggle_bluetooth" -> a11y!!.toggleSwitch(Intent(Settings.ACTION_BLUETOOTH_SETTINGS), listOf("Use Bluetooth", "Bluetooth"), desired(args)).json()
            "toggle_mobile_data" -> a11y!!.toggleSwitch(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY), listOf("Mobile data", "Mobile network", "SIM"), desired(args)).json()
            "rotate_screen" -> rotate(args.getString("orientation"))
            "compose_email" -> email(args)
            "send_sms" -> sms(args)
            else -> fail("Unknown tool $name")
        }
    }

    private fun openApp(query: String): JSONObject {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
        val q = query.trim().lowercase()
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return fail("No installed app called \"$query\"")
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return fail("Can't launch it")
        launch(i)
        return good("Opened ${hit.loadLabel(pm)}")
    }

    private fun rotate(o: String): JSONObject {
        if (!Settings.System.canWrite(ctx)) {
            launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            return fail("Need 'Modify system settings' permission. I opened the page; ask the user to allow it.")
        }
        val cr = ctx.contentResolver
        when (o) {
            "auto" -> Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 1)
            else -> {
                Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, 0)
                Settings.System.putInt(cr, Settings.System.USER_ROTATION,
                    if (o == "landscape") Surface.ROTATION_90 else Surface.ROTATION_0)
            }
        }
        return good("Orientation set to $o")
    }

    private suspend fun email(a: JSONObject): JSONObject {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_EMAIL, arrayOf(a.getString("to")))
            .putExtra(Intent.EXTRA_SUBJECT, a.getString("subject"))
            .putExtra(Intent.EXTRA_TEXT, a.getString("body"))
        launch(i)
        return maybeSend(a.optBoolean("confirmed_by_user"), "Email draft")
    }

    private suspend fun sms(a: JSONObject): JSONObject {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${a.getString("number")}"))
            .putExtra("sms_body", a.getString("message"))
        launch(i)
        return maybeSend(a.optBoolean("confirmed_by_user"), "Message draft")
    }

    private suspend fun maybeSend(confirmed: Boolean, what: String): JSONObject {
        if (!confirmed) return good("$what is open and NOT sent. Ask the user to confirm.")
        val a11y = MarvisAccessibilityService.instance ?: return good("$what open; enable accessibility so I can press Send.")
        delay(1800)
        val sent = a11y.clickByLabel(listOf("Send", "Send message", "Send SMS"))
        return if (sent) good("Sent") else fail("$what is open but I couldn't find the Send button.")
    }

    // ---------- Reminders ----------
    private suspend fun setReminder(a: JSONObject): JSONObject {
        val at = try { LocalDateTime.parse(a.getString("datetime_local")) }
                 catch (e: Exception) { return fail("Bad datetime; use yyyy-MM-ddTHH:mm") }
        if (at.isBefore(LocalDateTime.now())) return fail("That time is in the past")
        val r = MarvisApp.instance.reminders.create(
            a.getString("title"), at, Repeat.from(a.optString("repeat")), a.optString("kind", "reminder"))
        return good("Saved #${r.id} for ${at.format(DateTimeFormatter.ofPattern("EEE d MMM, h:mm a"))}")
    }

    private suspend fun listReminders(): JSONObject {
        val items = MarvisApp.instance.reminders.list().joinToString("; ") {
            "#${it.id} ${it.title} @ ${java.time.Instant.ofEpochMilli(it.triggerAt).atZone(java.time.ZoneId.systemDefault()).toLocalDateTime()} (${it.repeat})"
        }
        return good(items.ifEmpty { "No pending reminders" })
    }
}
