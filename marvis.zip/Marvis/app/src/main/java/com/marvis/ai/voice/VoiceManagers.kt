package com.marvis.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.marvis.ai.ai.Emotion
import java.util.Locale

/** Real-time speech-to-text. Must be created and used on the main thread. */
class SpeechManager(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onPartial(text: String)
        fun onFinal(text: String)
        fun onLevel(level: Float)   // 0..1, drives the orb
        fun onEnd()
        fun onError(message: String)
    }

    private val recognizer: SpeechRecognizer? =
        if (SpeechRecognizer.isRecognitionAvailable(ctx)) SpeechRecognizer.createSpeechRecognizer(ctx) else null

    init {
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) cb.onEnd() else cb.onFinal(t)
            }
            override fun onPartialResults(p: Bundle?) {
                p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let(cb::onPartial)
            }
            override fun onRmsChanged(rms: Float) = cb.onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f))
            override fun onError(code: Int) {
                if (code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) cb.onEnd()
                else cb.onError("Speech recognition error $code")
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
    }

    val available get() = recognizer != null

    fun start(locale: Locale = Locale.getDefault()) {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale.toLanguageTag())
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        recognizer?.startListening(i) ?: cb.onError("Speech recognition isn't available on this device")
    }

    fun stop() { recognizer?.stopListening() }
    fun release() { recognizer?.destroy() }
}

/** Emotion-tuned TTS: pitch/rate shift per tone. (Upgrade path: Gemini TTS / Live API native audio.) */
class TtsManager(ctx: Context, private val onSpeaking: (Boolean) -> Unit) {
    private var ready = false
    private val tts: TextToSpeech = TextToSpeech(ctx) { status ->
        if (status == TextToSpeech.SUCCESS) { ready = true; tts.language = Locale.getDefault() }
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) = onSpeaking(true)
            override fun onDone(id: String?) = onSpeaking(false)
            @Deprecated("Deprecated in Java") override fun onError(id: String?) = onSpeaking(false)
            override fun onStop(id: String?, interrupted: Boolean) = onSpeaking(false)
        })
    }

    fun speak(text: String, emotion: Emotion) {
        if (!ready || text.isBlank()) return
        tts.setPitch(emotion.pitch)
        tts.setSpeechRate(emotion.rate)
        tts.speak(clean(text), TextToSpeech.QUEUE_FLUSH, null, "marvis")
    }

    fun stop() { tts.stop(); onSpeaking(false) }
    fun release() { tts.shutdown() }

    private fun clean(s: String) = s.replace(Regex("https?://\\S+"), "link").replace(Regex("[*#_`>]"), "")
}
