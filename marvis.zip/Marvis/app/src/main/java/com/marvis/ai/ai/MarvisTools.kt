package com.marvis.ai.ai

import org.json.JSONArray

/** Gemini function declarations. Names must match ActionRouter. */
object MarvisTools {
    private const val DECLARATIONS = """
[
 {"name":"scroll","description":"Scroll the current screen.","parameters":{"type":"object","properties":{"direction":{"type":"string","enum":["up","down"]}},"required":["direction"]}},
 {"name":"tap","description":"Tap at screen pixel coordinates.","parameters":{"type":"object","properties":{"x":{"type":"integer"},"y":{"type":"integer"}},"required":["x","y"]}},
 {"name":"click_text","description":"Tap the on-screen button/element whose text or description matches.","parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
 {"name":"type_text","description":"Type text into the focused input field.","parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
 {"name":"open_app","description":"Launch an installed app by its visible name.","parameters":{"type":"object","properties":{"app_name":{"type":"string"}},"required":["app_name"]}},
 {"name":"system_action","description":"Press a system button.","parameters":{"type":"object","properties":{"action":{"type":"string","enum":["home","back","recents","notifications","quick_settings","lock_screen","screenshot"]}},"required":["action"]}},
 {"name":"toggle_wifi","description":"Turn Wi-Fi on/off.","parameters":{"type":"object","properties":{"state":{"type":"string","enum":["on","off","toggle"]}},"required":["state"]}},
 {"name":"toggle_bluetooth","description":"Turn Bluetooth on/off.","parameters":{"type":"object","properties":{"state":{"type":"string","enum":["on","off","toggle"]}},"required":["state"]}},
 {"name":"toggle_mobile_data","description":"Turn mobile data on/off.","parameters":{"type":"object","properties":{"state":{"type":"string","enum":["on","off","toggle"]}},"required":["state"]}},
 {"name":"rotate_screen","description":"Set screen orientation.","parameters":{"type":"object","properties":{"orientation":{"type":"string","enum":["portrait","landscape","auto"]}},"required":["orientation"]}},
 {"name":"read_screen_text","description":"Return the visible text of the current screen (works without a screenshot).","parameters":{"type":"object","properties":{}}},
 {"name":"compose_email","description":"Open an email draft; optionally send it.","parameters":{"type":"object","properties":{"to":{"type":"string"},"subject":{"type":"string"},"body":{"type":"string"},"confirmed_by_user":{"type":"boolean","description":"true only if the user explicitly said to send"}},"required":["to","subject","body"]}},
 {"name":"send_sms","description":"Open an SMS draft; optionally send it.","parameters":{"type":"object","properties":{"number":{"type":"string"},"message":{"type":"string"},"confirmed_by_user":{"type":"boolean"}},"required":["number","message"]}},
 {"name":"set_reminder","description":"Create a reminder, alarm or task.","parameters":{"type":"object","properties":{"title":{"type":"string"},"datetime_local":{"type":"string","description":"yyyy-MM-ddTHH:mm in the user's local time"},"repeat":{"type":"string","enum":["none","daily","weekly"]},"kind":{"type":"string","enum":["reminder","alarm","task"]}},"required":["title","datetime_local"]}},
 {"name":"list_reminders","description":"List pending reminders/tasks.","parameters":{"type":"object","properties":{}}},
 {"name":"cancel_reminder","description":"Delete a reminder by id.","parameters":{"type":"object","properties":{"id":{"type":"integer"}},"required":["id"]}}
]
"""
    val functionDeclarations: JSONArray get() = JSONArray(DECLARATIONS)
}
